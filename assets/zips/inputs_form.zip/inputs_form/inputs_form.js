document.addEventListener('DOMContentLoaded',()=>{
const f=document.getElementById('demo-form');
const s=document.getElementById('salida');
f.addEventListener('submit',ev=>{
ev.preventDefault();
const data=new FormData(f);
const obj={

}
;
for(const[k,v]of data.entries()){
obj[k]=v
}
obj['boletin']=f.boletin.checked;
obj['rango']=f.rango.value;
s.textContent=JSON.stringify(obj,null,2);

}
);

}
);
